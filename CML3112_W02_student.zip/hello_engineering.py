print("Hello from CML3112")
print("Four readings are available in site_inspection_log.csv")
