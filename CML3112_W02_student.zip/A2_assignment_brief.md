# A2 Proof of life

Start with `00_START_HERE.txt` in the student ZIP. Before class, only download/extract the ZIP and prepare your accounts. In class, start with `proof_of_life.ipynb`, complete the four numbered repair exercises when directed, then return to the main notebook to finish it.

**Only two files are uploaded for marking:** your renamed, completed `proof_of_life.ipynb` and your own `README.md`. The numbered notebooks are practice, not four additional submissions. The supplied README files are instructions; write your own programme, file list and run instructions.

Due at the start of Week 3. Submit the repository URL, `STUDENT_ID_W02.ipynb` and your `README.md` through the assignment form. Keep a downloaded copy. The grader reads the uploaded files; a repository URL alone is not evidence of its contents.

Your repository contains the notebook, supplied CSV, and a README with your program, file list and run instructions. The notebook must run from a fresh kernel and contain your explanation of execution order. Keep the four repaired practice notebooks as supporting evidence.

The 20-point automated rubric checks: valid roster ID in the notebook (2), `proof_sum == 4` (4), fresh-run `readings == 17` (4), and the four correct CSV records in `rows` (4). The local rubric assesses your execution-order explanation (3) and README evidence (3). These components are combined into one mark out of 20. Missing/corrupt uploads receive an actionable resubmission status, not an invented score. Existing Week 1 pass/redo work is preserved.
