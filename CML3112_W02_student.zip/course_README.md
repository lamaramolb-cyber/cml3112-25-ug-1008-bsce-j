# Week 2 student setup

Use Google Colab for the teaching practical. You need a Google account, a GitHub account and the ZIP for your cohort. No installation is required on your own laptop.

1. Open https://colab.research.google.com and upload `proof_of_life.ipynb` from your cohort ZIP.
2. In the Files sidebar, upload the CSV from the same ZIP. Files disappear when a Colab runtime resets, so keep the original ZIP.
3. Enter your roster student registration number. Run each cell using Shift+Enter. Make a note of the changing value when you repeat an increment cell.
4. Repair the four numbered notebooks. State the cause of each error in one sentence.
5. Restart the runtime and run all cells. The proof notebook should show 4, then 17, then 4 rows.
6. Create a repository on GitHub. Use Colab's File > Save a copy in GitHub to save the notebook to that existing repository. Add the CSV and a README describing your program, the files and how to run them. Avoid personal contact information in a public repository.
7. Download a copy named `STUDENT_ID_W02.ipynb`. Keep it even after saving to GitHub.

## Submission

A2 is due at the start of your Week 3 lecture. Submit the repository URL, notebook and README.md using the designated assignment form. If the form is unavailable during class, retain the notebook and the lecturer-recorded submission time; an outage must not silently become a late penalty. The form's displayed deadline is in Kampala time.

## Connection fallback

Use a pre-provisioned lab computer with Python 3 and Jupyter. Copy the cohort folder from USB or the local share and open the notebook in that folder. Run `python check_setup.py` first. The instructor rehearses this path before class. Pairing temporarily is allowed for access, but each student saves their own named submission.

Optional home installation comes after the practical. It does not replace the lab readiness check required before the Week 7 and Week 14 offline tests.

## Student Registration Number

Your Student Registration Number includes slashes. `99/TEST/000/DEMO-X` is a fictional format illustration only; never enter it as your own number. Keep the slashes in the notebook `STUDENT_ID` value and in the form. In filenames only, replace slashes with underscores: `99_TEST_000_DEMO-X_W02.ipynb`. Use your own number from the roster.
